package com.example.model.fbhelpdesk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FbHelpdeskApplication {

	public static void main(String[] args) {
		SpringApplication.run(FbHelpdeskApplication.class, args);
	}

}
